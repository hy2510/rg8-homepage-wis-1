// Never Search Advisor
export const NAVER_SEARCH_ADVISOR_ID =
  'a0428099b2529aafffa69c77fdaebc19ffa9e960'

export const NAVER_SEARCH_ADVISOR_META_KEY = 'naver-site-verification'
