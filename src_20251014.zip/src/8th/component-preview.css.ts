import { globalStyle, style } from '@vanilla-extract/css'

export const sample = style({})

globalStyle(`${sample} > div`, {
  border: '1px solid #cacaca',
})
globalStyle(`${sample} > div > img`, {
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  width: 500,
  height: 'auto',
  margin: 20,
})
