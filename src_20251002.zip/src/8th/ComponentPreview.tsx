'use client'

import { sample } from './component-preview.css'
import CalendarEventItem from '@/8th/features/achieve/ui/CalendarEventItem'
import CalendarGrid from '@/8th/features/achieve/ui/CalendarGrid'
import CalendarHeader from '@/8th/features/achieve/ui/CalendarHeader'
import CalendarItem from '@/8th/features/achieve/ui/CalendarItem'
import CalendarModal from '@/8th/features/achieve/ui/CalendarModal'
import ChallengeCurrentProgress from '@/8th/features/achieve/ui/ChallengeCurrentProgress'
import ChallengeTrophyCard from '@/8th/features/achieve/ui/ChallengeTrophyCard'
import ChallengeTrophyItem from '@/8th/features/achieve/ui/ChallengeTrophyItem'
import ChallengeTrophyModal from '@/8th/features/achieve/ui/ChallengeTrophyModal'
import DailyGoalCard from '@/8th/features/achieve/ui/DailyGoalCard'
import DailyGoalItem from '@/8th/features/achieve/ui/DailyGoalItem'
import DailyGoalSetting from '@/8th/features/achieve/ui/DailyGoalSetting'
import LevelMasterCard from '@/8th/features/achieve/ui/LevelMasterCard'
import LevelMasterItem from '@/8th/features/achieve/ui/LevelMasterItem'
import LevelMasterModal from '@/8th/features/achieve/ui/LevelMasterModal'
import ReadingUnitCard from '@/8th/features/achieve/ui/ReadingUnitCard'
import ReadingUnitStoryItem from '@/8th/features/achieve/ui/ReadingUnitStoryItem'
import ReadingUnitStoryModal from '@/8th/features/achieve/ui/ReadingUnitStoryModal'
import StreakCard from '@/8th/features/achieve/ui/StreakCard'
import StreakItem from '@/8th/features/achieve/ui/StreakItem'
import StreakModal from '@/8th/features/achieve/ui/StreakModal'
import DailyRGBookItem from '@/8th/features/daily/ui/DailyRGBookItem'
import DailyRGCourse from '@/8th/features/daily/ui/DailyRGCourse'
import DailyRGLevel from '@/8th/features/daily/ui/DailyRGLevel'
import DailyRGSearchHeader from '@/8th/features/daily/ui/DailyRGSearchHeader'
import DailyRGSearchTitleBar from '@/8th/features/daily/ui/DailyRGSearchTitleBar'
import BookInfoModal from '@/8th/features/library/ui/BookInfoModal'
import BookItem from '@/8th/features/library/ui/BookItem'
import BookList from '@/8th/features/library/ui/BookList'
import BookSearchHeader from '@/8th/features/library/ui/BookSearchHeader'
import BookSearchInfo from '@/8th/features/library/ui/BookSearchInfo'
import BookSearchTitleBar from '@/8th/features/library/ui/BookSearchTitleBar'
import FavoriteHeader from '@/8th/features/library/ui/FavoriteHeader'
import FavoriteTitleBar from '@/8th/features/library/ui/FavoriteTitleBar'
import KeywordSearchHeader from '@/8th/features/library/ui/KeywordSearchHeader'
import KeywordSearchTitleBar from '@/8th/features/library/ui/KeywordSearchTitleBar'
import LevelItem from '@/8th/features/library/ui/LevelItem'
import LevelReading from '@/8th/features/library/ui/LevelSection'
import RecentlyViewed from '@/8th/features/library/ui/RecentlyViewed'
import SearchBar from '@/8th/features/library/ui/SearchBar'
import SeriesItem from '@/8th/features/library/ui/SeriesItem'
import TryAgainTitleBar from '@/8th/features/library/ui/TryAgainTitleBar'
import RankCard from '@/8th/features/rank/ui/RankCard'
import RankCategory from '@/8th/features/rank/ui/RankCategory'
import RankChallengeHeader from '@/8th/features/rank/ui/RankChallengeHeader'
import RankChallengeItem from '@/8th/features/rank/ui/RankChallengeItem'
import RankChallengeSchoolItem from '@/8th/features/rank/ui/RankChallengeSchoolItem'
import RankChallengeSchoolList from '@/8th/features/rank/ui/RankChallengeSchoolList'
import RankHallOfFameHeader from '@/8th/features/rank/ui/RankHallOfFameHeader'
import RankHallOfFameItem from '@/8th/features/rank/ui/RankHallOfFameItem'
import RankHallOfFameList from '@/8th/features/rank/ui/RankHallOfFameList'
import RankLevelMasterHeader from '@/8th/features/rank/ui/RankLevelMasterHeader'
import RankLevelMasterItem from '@/8th/features/rank/ui/RankLevelMasterItem'
import RankLevelMasterList from '@/8th/features/rank/ui/RankLevelMasterList'
import RankMonthlyHeader from '@/8th/features/rank/ui/RankMonthlyHeader'
import RankMonthlyItem from '@/8th/features/rank/ui/RankMonthlyItem'
import RankMonthlyList from '@/8th/features/rank/ui/RankMonthlyList'
import RankTitleBar from '@/8th/features/rank/ui/RankTitleBar'
import AssessmentReportModal from '@/8th/features/review/ui/AssessmentReportModal'
import RecentReviewList from '@/8th/features/review/ui/RecentReviewList'
import ReviewBookItem from '@/8th/features/review/ui/ReviewBookItem'
import ReviewHeader from '@/8th/features/review/ui/ReviewHeader'
import ReviewList from '@/8th/features/review/ui/ReviewList'
import ReviewSpeakBookItem from '@/8th/features/review/ui/ReviewSpeakBookItem'
import ReviewTitleBar from '@/8th/features/review/ui/ReviewTitleBar'
import AccountInfoTitleBar from '@/8th/features/student/ui/AccountInfoTitleBar'
import ExtraOptionLayout from '@/8th/features/student/ui/ExtraOptionLayout'
import LevelTestHistory from '@/8th/features/student/ui/LevelTestHistory'
import LevelTestInfoModal from '@/8th/features/student/ui/LevelTestInfoModal'
import LevelTestStatusView from '@/8th/features/student/ui/LevelTestStatusView'
import SettingCheckSelector from '@/8th/features/student/ui/SettingCheckSelector'
import SettingHeader from '@/8th/features/student/ui/SettingHeader'
import SettingImageSelector from '@/8th/features/student/ui/SettingImageSelector'
import SettingRadioSelector from '@/8th/features/student/ui/SettingRadioSelector'
import SettingTitleBar from '@/8th/features/student/ui/SettingTitleBar'
import StudentInfoCard from '@/8th/features/student/ui/StudentInfoCard'
import StudentProfileCard from '@/8th/features/student/ui/StudentProfileCard'
import StudyStatusView from '@/8th/features/student/ui/StudyStatusView'
import TodoBookItem from '@/8th/features/todo/ui/TodoBookItem'
import TodoHeader from '@/8th/features/todo/ui/TodoHeader'
import TodoList from '@/8th/features/todo/ui/TodoList'
import TodoTitleBar from '@/8th/features/todo/ui/TodoTitleBar'
import { MoreButton } from '@/8th/shared/ui/Buttons'
import FooterMenu from '@/8th/shared/ui/FooterMenu'
import NavigationMenu from '@/8th/shared/ui/GlobalNavBar'
import Pagenation from '@/8th/shared/ui/Pagenation'
import CheckBox, { SearchField } from './shared/ui/Input'

export default function ComponentPreview() {
  return (
    <div className={`${sample}`}>
      <CalendarEventItem />
      <CalendarGrid />
      <CalendarHeader />
      <CalendarItem />
      <CalendarModal />
      <ChallengeCurrentProgress />
      <ChallengeTrophyCard />
      <ChallengeTrophyItem />
      <ChallengeTrophyModal />
      <DailyGoalCard />
      <DailyGoalItem />
      <DailyGoalSetting />
      <LevelMasterCard />
      <LevelMasterItem />
      <LevelMasterModal />
      <ReadingUnitCard />
      <ReadingUnitStoryItem />
      <ReadingUnitStoryModal />
      <StreakCard />
      <StreakItem />
      <StreakModal />
      {/*  */}
      <DailyRGBookItem
        bookNumber={1}
        imgUrl="https://wcfresource.a1edu.com/newsystem/image/dodoabc/cover/eb-pk-301.jpg"
        title="Alphabet Aa"
        point={1}
        isCurrent={true}
      />
      <DailyRGCourse />
      <DailyRGLevel />
      <DailyRGSearchHeader />
      <DailyRGSearchTitleBar />
      {/*  */}
      <BookInfoModal />
      <BookItem />
      <BookList />
      <BookSearchHeader />
      <BookSearchInfo />
      <BookSearchTitleBar />
      <FavoriteHeader />
      <FavoriteTitleBar />
      <KeywordSearchHeader />
      <KeywordSearchTitleBar />
      <LevelItem />
      <LevelReading />
      <MoreButton />
      <Pagenation />
      <RecentlyViewed />
      <SearchBar />
      <SeriesItem />
      <TryAgainTitleBar />
      {/*  */}
      <RankCard />
      <RankCategory />
      <RankChallengeHeader />
      <RankChallengeItem />
      <RankChallengeSchoolItem />
      <RankChallengeSchoolList />
      <RankHallOfFameHeader />
      <RankHallOfFameItem />
      <RankHallOfFameList />
      <RankLevelMasterHeader />
      <RankLevelMasterItem />
      <RankLevelMasterList />
      <RankMonthlyHeader />
      <RankMonthlyItem />
      <RankMonthlyList />
      <RankTitleBar />
      {/*  */}
      <AssessmentReportModal />
      <RecentReviewList />
      <ReviewBookItem />
      <ReviewHeader />
      <ReviewList />
      <ReviewSpeakBookItem />
      <ReviewTitleBar />
      {/*  */}
      <AccountInfoTitleBar />
      <CheckBox />
      <ExtraOptionLayout />
      <SearchField />
      <LevelTestHistory />
      <LevelTestInfoModal />
      <LevelTestStatusView />
      <SettingCheckSelector />
      <SettingHeader />
      <SettingImageSelector />
      <SettingRadioSelector />
      <SettingTitleBar />
      <StudentInfoCard />
      <StudentProfileCard />
      <StudyStatusView />
      {/*  */}
      <BookInfoModal />
      <MoreButton />
      <TodoBookItem />
      <TodoHeader />
      <TodoList />
      <TodoTitleBar />
      {/*  */}
      <NavigationMenu />
      <FooterMenu />
    </div>
  )
}
