import ComponentPreview from '@/8th/ComponentPreview'
import SITE_PATH from '@/app/site-path'
import Image from 'next/image'
import Link from 'next/link'

export default function Page() {
  return (
    <>
      <DevNavHeader />
      <Image src={'/src/8th/sample.png'} width="40" height="40" alt="" />
      <hr />
      <ComponentPreview />
    </>
  )
}

function DevNavHeader() {
  const NW8 = SITE_PATH.NW8

  return (
    <nav
      style={{
        display: 'flex',
        flexDirection: 'column',
        gap: '6px',
        padding: '8px',
        borderBottom: '1px solid #eee',
      }}>
      <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
        <strong style={{ minWidth: 72 }}>daily</strong>
        <Link href={NW8.DAILY_RG}>DAILY_RG</Link>
        {' | '}
        <Link href={NW8.DAILY_RESULT}>DAILY_RESULT</Link>
      </div>
      <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
        <strong style={{ minWidth: 72 }}>activity</strong>
        <Link href={NW8.ACTIVITY}>ACTIVITY</Link>
        {' | '}
        <Link href={NW8.TODO}>TODO</Link>
        {' | '}
        <Link href={NW8.FAVORITE}>FAVORITE</Link>
        {' | '}
        <Link href={NW8.TRYAGAIN}>TRYAGAIN</Link>
        {' | '}
        <Link href={NW8.REVIEW}>REVIEW</Link>
        {' | '}
        <Link href={NW8.ACCOUNT}>ACCOUNT</Link>
        {' | '}
        <Link href={NW8.SETTING}>SETTING</Link>
      </div>
      <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
        <strong style={{ minWidth: 72 }}>library</strong>
        <Link href={NW8.EB}>EB</Link>
        {' | '}
        <Link href={NW8.EB_LEVEL}>EB_LEVEL</Link>
        {' | '}
        <Link href={NW8.EB_SERIES}>EB_SERIES</Link>
        {' | '}
        <Link href={NW8.EB_MOVIE}>EB_MOVIE</Link>
        {' | '}
        <Link href={NW8.EB_WORKBOOK}>EB_WORKBOOK</Link>
        {' | '}
        <Link href={NW8.EB_SEARCH}>EB_SEARCH</Link>
        {' | '}
        <Link href={NW8.PB}>PB</Link>
        {' | '}
        <Link href={NW8.PB_LEVEL}>PB_LEVEL</Link>
        {' | '}
        <Link href={NW8.PB_SERIES}>PB_SERIES</Link>
        {' | '}
        <Link href={NW8.PB_SEARCH}>PB_SEARCH</Link>
        {' | '}
        <Link href={NW8.NEWBOOK}>NEWBOOK</Link>
      </div>
    </nav>
  )
}
